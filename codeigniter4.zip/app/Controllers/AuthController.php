<?php 

namespace App\Controllers;

use CodeIgniter\Controller;
use Config\Services;

class AuthController extends Controller 
{ 
    protected $authenticate; 

    public function __construct() 
    { 
        $this->authenticate = service('authentication');
    } 

    public function login() 
    { 
        $data = []; 

        if ($this->request->getMethod() === 'post') { 
            $rules = [ 
                'email'    => 'required|valid_email', 
                'password' => 'required' 
            ];

            $errors = [ 
                'password' => [ 
                    'required' => 'Please provide a password'
                ]
            ];

            if ($this->validate($rules, $errors)) {
                $email = $this->request->getPost('email');
                $password = $this->request->getPost('password');

                $rememberMe = $this->request->getPost('remember_me');

                if ($this->authenticate->attempt(['email' => $email, 'password' => $password], $rememberMe)) {
                    return redirect()->to('/dashboard');
                } else {
                    $data['error'] = 'Invalid email or password';
                }
            } else {
                $data['validation'] = $this->validator;
            }
        }

        return view('login', $data); 
    } 

    public function logout() 
    { 
        $this->authenticate->logout();

        return redirect()->to('/login'); 
    } 

    public function dashboard() 
    { 
        if (!$this->authenticate->check()) {
            return redirect()->to('/login');
        }

        $data['user'] = $this->authenticate->user();

        return view('dashboard', $data); 
    } 
}