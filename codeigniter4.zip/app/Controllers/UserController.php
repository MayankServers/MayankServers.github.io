<?php

namespace App\Controllers;

use App\Models\UserModel;

class UserController extends BaseController
{
    public function index()
    {
        $model = new UserModel();
        $data['users'] = $model->getUsers();
        
        return view('users', $data);
    }

    public function create()
    {
        $model = new UserModel();
        $data = [
            'username' => 'Mayank',
            'email'    => 'mayankreal657@gmail.com',
            'password' => 'M@y@nk657'
        ];

        $model->createUser($data);
    }

    public function update($id)
    {
        $model = new UserModel();
        $data = [
            'username' => 'Mayank',
            'email'    => 'mayankreal657@gmail.com',
            'password' => 'M@y@nk657'
        ];

        $model->updateUser($id, $data);
    }

    public function delete($id)
    {
        $model = new UserModel();
        $model->deleteUser($id);
    }
}